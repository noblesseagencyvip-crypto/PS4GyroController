package com.example.cdualps4;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * DualShock 4 companion/controller input tester.
 * Bluetooth HID pairing is handled by Android; gamepad input is delivered to this
 * Activity as normal Android KeyEvent/MotionEvent input.
 */
public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 41;
    private static final int REQUEST_ENABLE_BLUETOOTH = 42;
    private static final String PREFS = "controller_settings";
    private static final String[] ACTIONS = {
            "Unassigned", "Jump", "Fire", "Aim", "Reload", "Interact", "Menu", "Move", "Look"
    };

    private static final class ButtonBinding {
        final String label;
        final int keyCode;
        ButtonBinding(String label, int keyCode) {
            this.label = label;
            this.keyCode = keyCode;
        }
    }

    private static final class AxisBinding {
        final String label;
        final int axis;
        AxisBinding(String label, int axis) {
            this.label = label;
            this.axis = axis;
        }
    }

    private final List<ButtonBinding> buttonBindings = Arrays.asList(
            new ButtonBinding("Cross (×)", KeyEvent.KEYCODE_BUTTON_A),
            new ButtonBinding("Circle (○)", KeyEvent.KEYCODE_BUTTON_B),
            new ButtonBinding("Square (□)", KeyEvent.KEYCODE_BUTTON_X),
            new ButtonBinding("Triangle (△)", KeyEvent.KEYCODE_BUTTON_Y),
            new ButtonBinding("L1", KeyEvent.KEYCODE_BUTTON_L1),
            new ButtonBinding("R1", KeyEvent.KEYCODE_BUTTON_R1),
            new ButtonBinding("L2 (digital press)", KeyEvent.KEYCODE_BUTTON_L2),
            new ButtonBinding("R2 (digital press)", KeyEvent.KEYCODE_BUTTON_R2),
            new ButtonBinding("L3 (left stick click)", KeyEvent.KEYCODE_BUTTON_THUMBL),
            new ButtonBinding("R3 (right stick click)", KeyEvent.KEYCODE_BUTTON_THUMBR),
            new ButtonBinding("Options / Start", KeyEvent.KEYCODE_BUTTON_START),
            new ButtonBinding("Share / Select", KeyEvent.KEYCODE_BUTTON_SELECT),
            new ButtonBinding("PS / Mode", KeyEvent.KEYCODE_BUTTON_MODE),
            new ButtonBinding("D-pad Up", KeyEvent.KEYCODE_DPAD_UP),
            new ButtonBinding("D-pad Down", KeyEvent.KEYCODE_DPAD_DOWN),
            new ButtonBinding("D-pad Left", KeyEvent.KEYCODE_DPAD_LEFT),
            new ButtonBinding("D-pad Right", KeyEvent.KEYCODE_DPAD_RIGHT)
    );

    // Android exposes standardized joystick axes to apps. RX/RY/RZ are rotation axes;
    // generic axes are included for controllers/drivers that publish motion data there.
    private final List<AxisBinding> axisBindings = Arrays.asList(
            new AxisBinding("Left stick X", MotionEvent.AXIS_X),
            new AxisBinding("Left stick Y", MotionEvent.AXIS_Y),
            new AxisBinding("Right stick X / RX", MotionEvent.AXIS_RX),
            new AxisBinding("Right stick Y / RY", MotionEvent.AXIS_RY),
            new AxisBinding("Rotation Z / RZ", MotionEvent.AXIS_RZ),
            new AxisBinding("L2 analog trigger", MotionEvent.AXIS_LTRIGGER),
            new AxisBinding("R2 analog trigger", MotionEvent.AXIS_RTRIGGER),
            new AxisBinding("Motion / generic 1", MotionEvent.AXIS_GENERIC_1),
            new AxisBinding("Motion / generic 2", MotionEvent.AXIS_GENERIC_2),
            new AxisBinding("Motion / generic 3", MotionEvent.AXIS_GENERIC_3),
            new AxisBinding("Motion / generic 4", MotionEvent.AXIS_GENERIC_4),
            new AxisBinding("Motion / generic 5", MotionEvent.AXIS_GENERIC_5),
            new AxisBinding("Motion / generic 6", MotionEvent.AXIS_GENERIC_6)
    );

    private BluetoothAdapter bluetoothAdapter;
    private LinearLayout content;
    private TextView bluetoothStatus;
    private TextView inputStatus;
    private TextView eventStatus;
    private TextView colorPreview;
    private LinearLayout deviceList;
    private InputDevice selectedInputDevice;
    private boolean receiverRegistered;
    private int lightRed = 40;
    private int lightGreen = 120;
    private int lightBlue = 255;

    private final BroadcastReceiver bluetoothReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (device != null) addBluetoothDevice(device, false);
            } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                refreshBluetoothDevices();
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                setBluetoothStatus("Scan terminé. Sélectionnez une manette pour l'appairer.");
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(24, 30, 42));
        getWindow().setNavigationBarColor(Color.rgb(24, 30, 42));

        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        bluetoothAdapter = manager == null ? null : manager.getAdapter();
        loadColor();
        buildInterface();
        registerBluetoothReceiver();
        refreshInputDevices();
        if (hasBluetoothPermissions()) refreshBluetoothDevices();
        else requestBluetoothPermissions();
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(16), dp(18), dp(28));
        content.setBackgroundColor(Color.rgb(246, 247, 250));
        scroll.addView(content);
        setContentView(scroll);

        addText("cDualps4", 28, true, Color.rgb(25, 35, 55));
        addText("DualShock 4 • Bluetooth, commandes et profils", 14, false, Color.DKGRAY);

        addSection("1. Bluetooth et appairage");
        bluetoothStatus = addText("Vérification du Bluetooth…", 14, false, Color.DKGRAY);
        LinearLayout bluetoothButtons = horizontal();
        addButton(bluetoothButtons, "Activer Bluetooth", v -> enableBluetooth());
        addButton(bluetoothButtons, "Rechercher", v -> startBluetoothScan());
        addButton(bluetoothButtons, "Actualiser", v -> refreshBluetoothDevices());
        content.addView(bluetoothButtons);
        deviceList = new LinearLayout(this);
        deviceList.setOrientation(LinearLayout.VERTICAL);
        content.addView(deviceList);
        addText("Le système Android réalise l'appairage HID. Une fois appairée, la manette doit aussi apparaître comme périphérique d'entrée ci-dessous.", 13, false, Color.GRAY);

        addSection("2. Manette détectée / événements");
        inputStatus = addText("Aucune manette détectée.", 14, false, Color.DKGRAY);
        eventStatus = addText("Appuyez sur une touche ou bougez un stick pour tester.", 13, false, Color.rgb(45, 85, 145));
        Button refreshInput = new Button(this);
        refreshInput.setText("Actualiser les périphériques d'entrée");
        refreshInput.setOnClickListener(v -> refreshInputDevices());
        content.addView(refreshInput);

        addSection("3. Mappage des boutons");
        addText("Choisissez l'action à associer à chaque bouton. Les choix sont enregistrés automatiquement.", 13, false, Color.GRAY);
        for (ButtonBinding binding : buttonBindings) addMappingRow(binding.label, "button_" + binding.keyCode);

        addSection("4. Axes, sticks et mouvement");
        addText("Les axes ne sont disponibles que si Android les expose pour cette manette. RX/RY/RZ et les axes génériques peuvent représenter des données de rotation selon le pilote; Android ne fournit pas d'API universelle de gyroscope brut DualShock 4.", 13, false, Color.GRAY);
        for (AxisBinding binding : axisBindings) addMappingRow(binding.label, "axis_" + binding.axis);

        addSection("5. Retour haptique");
        addText("Teste le vibreur exposé par Android pour la manette sélectionnée (si le pilote le prend en charge).", 13, false, Color.GRAY);
        Button rumble = new Button(this);
        rumble.setText("Tester la vibration de la manette");
        rumble.setOnClickListener(v -> testControllerRumble());
        content.addView(rumble);

        addSection("6. Couleur Lightbar");
        addText("La couleur est mémorisée dans ce profil. Android n'expose pas d'API Bluetooth publique pour envoyer les rapports HID propriétaires de couleur à une DualShock 4; l'application ne peut donc pas garantir l'écriture sur la barre lumineuse sans prise en charge spécifique du système/pilote.", 13, false, Color.GRAY);
        colorPreview = addText("Couleur enregistrée", 16, true, Color.WHITE);
        colorPreview.setPadding(dp(12), dp(12), dp(12), dp(12));
        addColorSlider("Rouge", lightRed, value -> { lightRed = value; updateColorPreview(); });
        addColorSlider("Vert", lightGreen, value -> { lightGreen = value; updateColorPreview(); });
        addColorSlider("Bleu", lightBlue, value -> { lightBlue = value; updateColorPreview(); });
        Button saveColor = new Button(this);
        saveColor.setText("Enregistrer la couleur du profil");
        saveColor.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putInt("light_red", lightRed).putInt("light_green", lightGreen)
                    .putInt("light_blue", lightBlue).apply();
            updateColorPreview();
            Toast.makeText(this, "Couleur sauvegardée sur cet appareil", Toast.LENGTH_SHORT).show();
        });
        content.addView(saveColor);
        updateColorPreview();
    }

    private void addMappingRow(String label, String preferenceKey) {
        LinearLayout row = horizontal();
        TextView name = new TextView(this);
        name.setText(label);
        name.setTextSize(14);
        name.setTextColor(Color.rgb(40, 45, 55));
        row.addView(name, new LinearLayout.LayoutParams(0, dp(48), 1));
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ACTIONS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        int saved = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(preferenceKey, 0);
        spinner.setSelection(Math.max(0, Math.min(saved, ACTIONS.length - 1)));
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(preferenceKey, position).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        row.addView(spinner, new LinearLayout.LayoutParams(dp(145), dp(48)));
        content.addView(row);
    }

    private void addColorSlider(String label, int initial, IntConsumer consumer) {
        TextView title = addText(label, 13, true, Color.DKGRAY);
        SeekBar bar = new SeekBar(this);
        bar.setMax(255);
        bar.setProgress(initial);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { consumer.accept(progress); }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        content.addView(bar);
    }

    private interface IntConsumer { void accept(int value); }

    private void loadColor() {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        lightRed = prefs.getInt("light_red", lightRed);
        lightGreen = prefs.getInt("light_green", lightGreen);
        lightBlue = prefs.getInt("light_blue", lightBlue);
    }

    private void updateColorPreview() {
        if (colorPreview == null) return;
        int color = Color.rgb(lightRed, lightGreen, lightBlue);
        colorPreview.setBackgroundColor(color);
        colorPreview.setText(String.format("Lightbar profile  #%02X%02X%02X", lightRed, lightGreen, lightBlue));
        colorPreview.setTextColor((lightRed * 299 + lightGreen * 587 + lightBlue * 114) / 1000 > 145 ? Color.BLACK : Color.WHITE);
    }

    private void addSection(String title) {
        TextView text = addText(title, 19, true, Color.rgb(30, 53, 91));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) text.getLayoutParams();
        params.topMargin = dp(20);
        params.bottomMargin = dp(5);
        text.setLayoutParams(params);
    }

    private TextView addText(String value, int size, boolean bold, int color) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(null, android.graphics.Typeface.BOLD);
        text.setPadding(0, dp(4), 0, dp(4));
        content.addView(text);
        return text;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        return row;
    }

    private void addButton(LinearLayout parent, String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(12);
        button.setOnClickListener(listener);
        parent.addView(button, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private boolean hasBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return Build.VERSION.SDK_INT >= 23
                ? checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                : true;
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, REQUEST_PERMISSIONS);
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (hasBluetoothPermissions()) refreshBluetoothDevices();
            else setBluetoothStatus("Permission Bluetooth refusée. Les événements de manette déjà connectée peuvent néanmoins fonctionner.");
        }
    }

    private void enableBluetooth() {
        if (bluetoothAdapter == null) {
            setBluetoothStatus("Bluetooth indisponible sur cet appareil.");
            return;
        }
        if (!hasBluetoothPermissions()) { requestBluetoothPermissions(); return; }
        if (!bluetoothAdapter.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BLUETOOTH);
        } else {
            setBluetoothStatus("Bluetooth activé.");
            refreshBluetoothDevices();
        }
    }

    private void startBluetoothScan() {
        if (bluetoothAdapter == null) { setBluetoothStatus("Bluetooth indisponible."); return; }
        if (!hasBluetoothPermissions()) { requestBluetoothPermissions(); return; }
        if (!bluetoothAdapter.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BLUETOOTH);
            return;
        }
        try {
            if (bluetoothAdapter.isDiscovering()) bluetoothAdapter.cancelDiscovery();
            deviceList.removeAllViews();
            setBluetoothStatus("Recherche en cours… Mettez la manette en mode appairage (Share + PS jusqu'au clignotement rapide).");
            bluetoothAdapter.startDiscovery();
        } catch (SecurityException exception) {
            setBluetoothStatus("Permission Bluetooth manquante : " + exception.getMessage());
        }
    }

    private void registerBluetoothReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(bluetoothReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(bluetoothReceiver, filter);
            receiverRegistered = true;
        } catch (RuntimeException ignored) { receiverRegistered = false; }
    }

    private void refreshBluetoothDevices() {
        if (bluetoothAdapter == null) { setBluetoothStatus("Bluetooth indisponible sur cet appareil."); return; }
        if (!hasBluetoothPermissions()) { setBluetoothStatus("Autorisez Bluetooth pour rechercher ou appairer une manette."); return; }
        try {
            deviceList.removeAllViews();
            if (!bluetoothAdapter.isEnabled()) {
                setBluetoothStatus("Bluetooth désactivé. Touchez « Activer Bluetooth ».");
                return;
            }
            Set<BluetoothDevice> bonded = bluetoothAdapter.getBondedDevices();
            if (bonded != null) for (BluetoothDevice device : bonded) addBluetoothDevice(device, true);
            setBluetoothStatus("Appareils déjà appairés : " + (bonded == null ? 0 : bonded.size()) + ". Lancez une recherche pour ajouter une manette.");
        } catch (SecurityException exception) {
            setBluetoothStatus("Accès Bluetooth refusé.");
        }
    }

    private void addBluetoothDevice(BluetoothDevice device, boolean bonded) {
        if (deviceList == null) return;
        try {
            String name = device.getName();
            if (name == null || name.trim().isEmpty()) name = "Périphérique Bluetooth";
            String address = device.getAddress();
            final BluetoothDevice target = device;
            LinearLayout row = horizontal();
            TextView text = new TextView(this);
            text.setText(name + (bonded ? "  •  appairé" : "  •  disponible") + "\n" + address);
            text.setTextSize(13);
            text.setTextColor(Color.DKGRAY);
            row.addView(text, new LinearLayout.LayoutParams(0, dp(58), 1));
            Button pair = new Button(this);
            pair.setText(bonded ? "Ouvrir Bluetooth" : "Appairer");
            pair.setOnClickListener(v -> {
                try {
                    if (target.getBondState() == BluetoothDevice.BOND_BONDED) {
                        startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
                    } else {
                        setBluetoothStatus("Demande d'appairage envoyée à Android…");
                        target.createBond();
                    }
                } catch (SecurityException exception) {
                    setBluetoothStatus("Autorisez la permission Bluetooth puis réessayez.");
                }
            });
            row.addView(pair);
            deviceList.addView(row);
        } catch (SecurityException ignored) { }
    }

    private void setBluetoothStatus(String value) {
        if (bluetoothStatus != null) bluetoothStatus.setText(value);
    }

    private void refreshInputDevices() {
        int[] ids = InputDevice.getDeviceIds();
        List<InputDevice> gamepads = new ArrayList<>();
        for (int id : ids) {
            InputDevice device = InputDevice.getDevice(id);
            if (device == null) continue;
            int sources = device.getSources();
            if ((sources & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                    || (sources & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                gamepads.add(device);
            }
        }
        if (gamepads.isEmpty()) {
            selectedInputDevice = null;
            inputStatus.setText("Aucune manette détectée comme périphérique d'entrée. Appairez la DualShock 4 dans les paramètres Bluetooth Android.");
            return;
        }
        selectedInputDevice = gamepads.get(0);
        StringBuilder summary = new StringBuilder("Périphérique actif : ");
        for (InputDevice device : gamepads) {
            summary.append("\n• ").append(device.getName()).append(" (ID ").append(device.getId()).append(")");
        }
        inputStatus.setText(summary.toString());
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && isControllerEvent(event)) {
            String action = mappedAction("button_" + event.getKeyCode());
            eventStatus.setText("Touche : " + KeyEvent.keyCodeToString(event.getKeyCode()) + " → " + action);
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent event) {
        if ((event.getSource() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                && event.getAction() == MotionEvent.ACTION_MOVE) {
            InputDevice device = event.getDevice();
            if (device != null) selectedInputDevice = device;
            StringBuilder values = new StringBuilder("Axes : ");
            int shown = 0;
            for (AxisBinding binding : axisBindings) {
                if (event.getDevice() != null && event.getDevice().getMotionRange(binding.axis, event.getSource()) != null) {
                    float value = event.getAxisValue(binding.axis);
                    if (Math.abs(value) > 0.08f) {
                        if (shown++ > 0) values.append(" • ");
                        values.append(binding.label).append('=').append(String.format(java.util.Locale.US, "%.2f", value));
                        if (Math.abs(value) > 0.5f) {
                            String action = mappedAction("axis_" + binding.axis);
                            if (!"Unassigned".equals(action)) values.append(" → ").append(action);
                        }
                    }
                }
            }
            if (shown == 0) values.append("aucun mouvement significatif");
            eventStatus.setText(values.toString());
        }
        return super.dispatchGenericMotionEvent(event);
    }

    private boolean isControllerEvent(KeyEvent event) {
        InputDevice device = event.getDevice();
        if (device != null && ((device.getSources() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD
                || (device.getSources() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK)) {
            selectedInputDevice = device;
            return true;
        }
        return event.getKeyCode() >= KeyEvent.KEYCODE_BUTTON_A && event.getKeyCode() <= KeyEvent.KEYCODE_BUTTON_MODE;
    }

    private String mappedAction(String key) {
        int selected = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(key, 0);
        return ACTIONS[Math.max(0, Math.min(selected, ACTIONS.length - 1))];
    }

    private void testControllerRumble() {
        if (selectedInputDevice == null) refreshInputDevices();
        try {
            if (selectedInputDevice == null) {
                Toast.makeText(this, "Aucune manette d'entrée sélectionnée.", Toast.LENGTH_LONG).show();
                return;
            }
            Vibrator vibrator = selectedInputDevice.getVibrator();
            if (vibrator == null || !vibrator.hasVibrator()) {
                Toast.makeText(this, "Le système/pilote n'expose pas de vibreur pour cette manette.", Toast.LENGTH_LONG).show();
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(300);
            Toast.makeText(this, "Commande de vibration envoyée.", Toast.LENGTH_SHORT).show();
        } catch (SecurityException exception) {
            Toast.makeText(this, "Permission de vibration refusée.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ENABLE_BLUETOOTH) refreshBluetoothDevices();
    }

    @Override protected void onDestroy() {
        if (bluetoothAdapter != null && hasBluetoothPermissions()) {
            try { if (bluetoothAdapter.isDiscovering()) bluetoothAdapter.cancelDiscovery(); }
            catch (SecurityException ignored) { }
        }
        if (receiverRegistered) {
            try { unregisterReceiver(bluetoothReceiver); }
            catch (IllegalArgumentException ignored) { }
        }
        super.onDestroy();
    }
}
